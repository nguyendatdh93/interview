Code
--------------------
- Unzip code to folder.
- Copy folder to your environment for run app PHP. (XAMP,...);
- run : http://localhost/demo/backend/Controller.php.
Database
--------------------
- Create a database name : blog_demo
- import file sql to database.

Thanks.
